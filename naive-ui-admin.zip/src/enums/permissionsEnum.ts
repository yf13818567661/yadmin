export interface PermissionsEnum {
  value: string;
  label: string;
}
