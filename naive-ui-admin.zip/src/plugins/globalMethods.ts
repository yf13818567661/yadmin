/**
 * 注册全局方法 待完善
 * @param app
 */
export function setupGlobalMethods() {}
