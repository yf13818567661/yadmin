import Logo from './index.vue';

export { Logo };
