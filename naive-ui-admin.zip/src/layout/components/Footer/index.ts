import PageFooter from './index.vue';

export { PageFooter };
