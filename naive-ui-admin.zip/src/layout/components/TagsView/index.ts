import TabsView from './index.vue';

export { TabsView };
