import{_ as e,o,c as s,a as t}from"./index-QId0_h2g.js";const c={},a={class:"about"},n=t("h1",null,"This is an about page",-1),_=[n];function r(i,d){return o(),s("div",a,_)}const u=e(c,[["render",r]]);export{u as default};
//# sourceMappingURL=AboutView-x0DHdBhk.js.map
